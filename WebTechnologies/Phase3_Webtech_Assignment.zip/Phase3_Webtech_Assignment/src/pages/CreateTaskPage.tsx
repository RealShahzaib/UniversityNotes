import React from "react";
import { Task } from "../types/task";
import { TaskForm } from "../components/TaskForm";

type CreateTaskPageProps = {
  onSubmitTask: (taskData: Omit<Task, "id" | "createdAt">) => void;
  editingTask: Task | null;
  onCancelEdit: () => void;
};

export const CreateTaskPage: React.FC<CreateTaskPageProps> = ({ onSubmitTask, editingTask, onCancelEdit }) => {
  return (
    <section className="card form-section" style={{ width: "100%", maxWidth: "600px", margin: "0 auto" }}>
      <h2>{editingTask ? "Edit Task" : "Create Task"}</h2>
      <p className="subtitle">{editingTask ? "Modify your task values" : "Form UI"}</p>
      
      <TaskForm 
        onSubmitTask={onSubmitTask} 
        editingTask={editingTask} 
        onCancelEdit={onCancelEdit} 
      />
    </section>
  );
};