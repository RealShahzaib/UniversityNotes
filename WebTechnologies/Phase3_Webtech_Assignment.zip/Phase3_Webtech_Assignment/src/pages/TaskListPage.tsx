import React from "react";
import { Task } from "../types/task";
import { TaskCard } from "../components/TaskCard";

type TaskListPageProps = {
  tasks: Task[];
  onDeleteTask: (id: number) => void;
  onEditTaskTrigger: (task: Task) => void;
};

export const TaskListPage: React.FC<TaskListPageProps> = ({ tasks, onDeleteTask, onEditTaskTrigger }) => {
  return (
    <section className="card task-list-section" style={{ width: "100%" }}>
      <h2>My Tasks</h2>
      <p className="subtitle">Phase 2 UI - State-based rendering items</p>

      <div className="tasks-container">
        {tasks.length === 0 ? (
          <p style={{ color: "var(--text-muted)", textAlign: "center", padding: "20px" }}>
            No tasks found. Create a new task!
          </p>
        ) : (
          tasks.map((task) => (
            <TaskCard 
              key={task.id} 
              task={task} 
              onDelete={onDeleteTask} 
              onEdit={onEditTaskTrigger} 
            />
          ))
        )}
      </div>
    </section>
  );
};