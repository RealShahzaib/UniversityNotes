import { Task } from "../types/task";

export const initialTasks: Task[] = [
  {
    id: 1,
    title: "Complete HTML structure",
    description: "Create semantic HTML structure for the TaskFlow page.",
    status: "Done",
    priority: "High",
    dueDate: "2026-03-20",
    createdAt: "2026-03-20"
  },
  {
    id: 2,
    title: "Create HTML skeleton",
    description: "Set up the structural base framework of the app layout.",
    status: "Done",
    priority: "Medium",
    dueDate: "2026-03-21",
    createdAt: "2026-03-21"
  },
  {
    id: 3,
    title: "Apply CSS Flexbox styling",
    description: "Build a responsive grid and card-based interface structure.",
    status: "In Progress",
    priority: "High",
    dueDate: "2026-03-23",
    createdAt: "2026-03-22"
  },
  {
    id: 4,
    title: "Write JavaScript logic",
    description: "Handle structural baseline creation and modification arrays dynamically.",
    status: "Todo",
    priority: "Medium",
    dueDate: "2026-03-24",
    createdAt: "2026-03-23"
  },
  {
    id: 5,
    title: "Record demo video",
    description: "Walk through the interface actions showcasing responsiveness and code alignment.",
    status: "Todo",
    priority: "Low",
    dueDate: "2026-03-25",
    createdAt: "2026-03-24"
  }
];