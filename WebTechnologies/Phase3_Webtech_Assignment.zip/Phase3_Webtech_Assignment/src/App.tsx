import React, { useState } from "react";
import { Routes, Route, NavLink, useNavigate } from "react-router-dom";
import { TaskForm } from "./components/TaskForm";
import { TaskCard } from "./components/TaskCard";
import { initialTasks } from "./data/mockTasks";
import { Task } from "./types/task";

export const App: React.FC = () => {
  const [tasks, setTasks] = useState<Task[]>(initialTasks);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  const navigate = useNavigate();

  const handleDeleteTask = (id: number) => {
    if (editingTask?.id === id) setEditingTask(null);
    setTasks(tasks.filter((task) => task.id !== id));
  };

  const handleEditTrigger = (task: Task) => {
    setEditingTask(task);
    navigate("/create"); // Navigates to the dedicated form page
  };

  const handleFormSubmit = (taskData: Omit<Task, "id" | "createdAt">) => {
    if (editingTask) {
      setTasks(tasks.map((t) => (t.id === editingTask.id ? { ...t, ...taskData } : t)));
      setEditingTask(null);
    } else {
      const newTask: Task = {
        ...taskData,
        id: tasks.length > 0 ? Math.max(...tasks.map((t) => t.id)) + 1 : 1,
        createdAt: new Date().toISOString().split("T")[0]
      };
      setTasks([...tasks, newTask]);
    }
    navigate("/"); // Redirects back to Dashboard after saving
  };

  return (
    <div className="page">
      {/* Fixed Left Sidebar Navigation Panel */}
      <aside className="sidebar-panel">
        <div className="sidebar-header">
          <div className="logo-badge">TF</div>
          <h1 className="sidebar-title">TaskFlow</h1>
        </div>
        <ul className="sidebar-nav">
          <li>
            <NavLink to="/" className={({ isActive }) => (isActive ? "active" : "")}>
              Dashboard View
            </NavLink>
          </li>
          <li>
            <NavLink to="/create" className={({ isActive }) => (isActive ? "active" : "")}>
              {editingTask ? "✍️ Editing Task" : "➕ New Task Page"}
            </NavLink>
          </li>
        </ul>
        <button className="btn logout-btn" onClick={() => alert("Logout placeholder interaction functionality!")}>
          Exit Workspace
        </button>
      </aside>

      {/* Main Content Viewport Context Canvas */}
      <main className="main-content">
        <header className="top-action-bar">
          <div>
            <h2>Project Control Panel</h2>
            <p style={{ color: "var(--text-muted)", fontSize: "0.9rem" }}>Section A Portal Workspace</p>
          </div>
          <div style={{ fontSize: "0.9rem", fontWeight: 600, color: "var(--primary-color)" }}>
            Total Open Tasks: {tasks.length}
          </div>
        </header>

        {/* Dynamic Page Component Mounting Point */}
        <Routes>
          {/* Page 1: Clean Dashboard (Only shows tasks) */}
          <Route 
            path="/" 
            element={
              <section className="card">
                <h2>Live Feed Task Array Tracker</h2>
                <p className="subtitle">Reactive State Management Engine Render Loop</p>
                <div className="tasks-container">
                  {tasks.length === 0 ? (
                    <p style={{ color: "var(--text-muted)", textAlign: "center", padding: "40px" }}>
                      Workspace empty. Click 'New Task Page' to add an item.
                    </p>
                  ) : (
                    tasks.map((task) => (
                      <TaskCard 
                        key={task.id} 
                        task={task} 
                        onDelete={handleDeleteTask} 
                        onEdit={handleEditTrigger} 
                      />
                    ))
                  )}
                </div>
              </section>
            } 
          />

          {/* Page 2: Dedicated Full-Width Creation/Editing Workspace */}
          <Route 
            path="/create" 
            element={
              <section className="card" style={{ maxWidth: "650px", margin: "0 auto", width: "100%" }}>
                <h2>{editingTask ? "Modify Task Frame" : "Register New Task Item"}</h2>
                <p className="subtitle">Form UI Controller Block State Sync</p>
                <TaskForm 
                  onSubmitTask={handleFormSubmit} 
                  editingTask={editingTask} 
                  onCancelEdit={() => {
                    setEditingTask(null);
                    navigate("/");
                  }} 
                />
              </section>
            } 
          />
        </Routes>

        <footer className="app-footer">
          <p>&copy; 2026 TaskFlow | Architectural System Redesign Portfolio Build by <strong>Shahzaib Shah</strong></p>
        </footer>
      </main>
    </div>
  );
};

export default App;