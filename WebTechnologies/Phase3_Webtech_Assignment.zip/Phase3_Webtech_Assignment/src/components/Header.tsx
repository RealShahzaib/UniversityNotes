import React from "react";

export const Header: React.FC = () => {
  const handleLogout = () => {
    alert("Logout functionality is a placeholder for a future phase!");
  };

  return (
    <header className="app-header">
      <div className="header-left">
        <div className="logo-placeholder">TF</div>
        <h1 className="app-title">TaskFlow (Section A)</h1>
      </div>
      <div className="header-right">
        <button className="btn logout-btn" onClick={handleLogout}>
          Logout
        </button>
      </div>
    </header>
  );
};