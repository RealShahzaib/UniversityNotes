import React from "react";
import { Task } from "../types/task";

type TaskCardProps = {
  task: Task;
  onDelete: (id: number) => void;
  onEdit: (task: Task) => void;
};

export const TaskCard: React.FC<TaskCardProps> = ({ task, onDelete, onEdit }) => {
  // Convert standard dynamic input names to clean layout identifiers
  const statusClass = task.status.toLowerCase().replace(" ", "");
  const priorityClass = task.priority.toLowerCase();

  return (
    <div className="task-item">
      <div className="task-info">
        <span className="task-title">{task.title}</span>
        {task.description && <p className="task-desc">{task.description}</p>}
        
        <div className="task-badges">
          <span className={`badge status-${statusClass}`}>{task.status}</span>
          <span className={`badge priority-${priorityClass}`}>{task.priority} Priority</span>
          {task.dueDate && (
            <span className="task-date">📅 Due: {task.dueDate}</span>
          )}
        </div>
      </div>
      
      <div className="task-actions-btns">
        <button className="btn edit-btn" onClick={() => onEdit(task)}>
          Edit
        </button>
        <button className="btn delete-btn" onClick={() => onDelete(task.id)}>
          Delete
        </button>
      </div>
    </div>
  );
};