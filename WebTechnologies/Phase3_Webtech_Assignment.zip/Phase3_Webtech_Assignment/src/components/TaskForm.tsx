import React, { useState, useEffect } from "react";
import { Task, TaskStatus, TaskPriority } from "../types/task";

type TaskFormProps = {
  onSubmitTask: (taskData: Omit<Task, "id" | "createdAt">) => void;
  editingTask: Task | null;
  onCancelEdit: () => void;
};

export const TaskForm: React.FC<TaskFormProps> = ({ onSubmitTask, editingTask, onCancelEdit }) => {
  const [title, setTitle] = useState<string>("");
  const [description, setDescription] = useState<string>("");
  const [status, setStatus] = useState<TaskStatus>("Todo");
  const [priority, setPriority] = useState<TaskPriority>("Low");
  const [dueDate, setDueDate] = useState<string>("");
  const [error, setError] = useState<string>("");

  // Sync state if an existing item gets tapped for structural adjustments (Bonus Feature Requirement)
  useEffect(() => {
    if (editingTask) {
      setTitle(editingTask.title);
      setDescription(editingTask.description);
      setStatus(editingTask.status);
      setPriority(editingTask.priority);
      setDueDate(editingTask.dueDate || "");
    } else {
      resetFormFields();
    }
  }, [editingTask]);

  const resetFormFields = () => {
    setTitle("");
    setDescription("");
    setStatus("Todo");
    setPriority("Low");
    setDueDate("");
    setError("");
  };

  const handleSubmit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();

    if (title.trim() === "") {
      setError("Task title is required.");
      return;
    }

    setError("");
    onSubmitTask({
      title: title.trim(),
      description: description.trim(),
      status,
      priority,
      dueDate: dueDate || undefined
    });

    resetFormFields();
  };

  const handleReset = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    resetFormFields();
    if (editingTask) {
      onCancelEdit();
    }
  };

  return (
    <form className="task-form" onSubmit={handleSubmit} onReset={handleReset}>
      <div className="form-group">
        <label htmlFor="taskTitle" className="form-label">Title</label>
        <input
          type="text"
          id="taskTitle"
          className="input field-input"
          placeholder="Enter title..."
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        {error && <span className="validation-msg">{error}</span>}
      </div>

      <div className="form-group">
        <label htmlFor="taskDescription" className="form-label">Description / Content</label>
        <textarea
          id="taskDescription"
          className="input field-input"
          rows={3}
          placeholder="Task description..."
          value={description}
          onChange={(e) => setDescription(e.target.value)}
        ></textarea>
      </div>

      <div className="form-group">
        <label htmlFor="taskStatus" className="form-label">Status</label>
        <select
          id="taskStatus"
          className="input field-input"
          value={status}
          onChange={(e) => setStatus(e.target.value as TaskStatus)}
        >
          <option value="Todo">Todo</option>
          <option value="In Progress">In Progress</option>
          <option value="Done">Done</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="taskPriority" className="form-label">Priority</label>
        <select
          id="taskPriority"
          className="input field-input"
          value={priority}
          onChange={(e) => setPriority(e.target.value as TaskPriority)}
        >
          <option value="Low">Low</option>
          <option value="Medium">Medium</option>
          <option value="High">High</option>
        </select>
      </div>

      <div className="form-group">
        <label htmlFor="taskDueDate" className="form-label">Due Date (Optional)</label>
        <input
          type="date"
          id="taskDueDate"
          className="input field-input"
          value={dueDate}
          onChange={(e) => setDueDate(e.target.value)}
        />
      </div>

      <div className="form-actions">
        <button type="reset" className="btn clear-btn">
          {editingTask ? "Cancel" : "Clear"}
        </button>
        <button type="submit" className="btn primary-btn">
          {editingTask ? "Update Task" : "Create Task"}
        </button>
      </div>
    </form>
  );
};