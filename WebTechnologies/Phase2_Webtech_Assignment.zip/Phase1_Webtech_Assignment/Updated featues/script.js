document.addEventListener('DOMContentLoaded', () => {
    // Basic DOM Selection
    const taskForm = document.querySelector('.task-form');
    const tasksContainer = document.querySelector('.tasks-container');
    const titleInput = document.querySelector('#taskTitle');
    const statusSelect = document.querySelector('#taskStatus');
    const dueDateInput = document.querySelector('#taskDueDate');
    const validationMsg = document.querySelector('.validation-msg');
    
    // Select the submit button to dynamically change text
    const submitBtn = taskForm.querySelector('.primary-btn');
    
    // Track the task currently being edited (null when in creation mode)
    let editingTask = null;
    
    // Select placeholder elements
    const logoutBtn = document.querySelector('.logout-btn');
    const navLinks = document.querySelectorAll('.nav-links a:not(.active)');

    // 1. Add / Update Task Interaction
    taskForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent page refresh

        // Basic Validation
        const titleValue = titleInput.value.trim();
        if (titleValue === '') {
            validationMsg.classList.remove('hidden');
            return;
        }
        
        validationMsg.classList.add('hidden');

        // Gather form values
        const statusValue = statusSelect.value;
        let dateValue = dueDateInput.value;
        if (!dateValue) {
            dateValue = 'No due date';
        }

        if (editingTask) {
            // --- UPDATE MODE ---
            // Update the existing DOM elements inside the selected task card
            editingTask.querySelector('strong').textContent = `New Task: ${titleValue}`;
            editingTask.querySelector('.task-meta').textContent = `${statusValue} | Due: ${dateValue}`;
            
            // Reset state back to create mode
            editingTask = null;
            submitBtn.textContent = 'Create Task';
        } else {
            // --- CREATE MODE ---
            const newTask = document.createElement('div');
            newTask.classList.add('task-item');
            
            newTask.innerHTML = `
                <div class="task-info">
                    <strong>New Task: ${titleValue}</strong>
                    <span class="task-meta">${statusValue} | Due: ${dateValue}</span>
                </div>
                <div class="task-actions-btns">
                    <button class="btn edit-btn">Edit</button>
                    <button class="btn delete-btn">Delete</button>
                </div>
            `;

            // Append to the list
            tasksContainer.appendChild(newTask);
        }

        // Reset the form after successful submission/update
        taskForm.reset();
    });

    // Reset Form Event Listener (Handles cleanup if user hits Clear while editing)
    taskForm.addEventListener('reset', () => {
        editingTask = null;
        submitBtn.textContent = 'Create Task';
        validationMsg.classList.add('hidden');
    });

    // 2. Click Interactions inside Tasks Container (Delete & Edit)
    tasksContainer.addEventListener('click', function(event) {
        const taskItem = event.target.closest('.task-item');
        if (!taskItem) return;

        // HANDLE DELETE
        if (event.target.classList.contains('delete-btn')) {
            // If deleting the task currently being edited, reset the form state
            if (taskItem === editingTask) {
                taskForm.reset();
            }
            taskItem.remove(); 
        }

        // HANDLE EDIT
        if (event.target.classList.contains('edit-btn')) {
            editingTask = taskItem;

            // Extract values from the DOM structure
            const fullTitleText = taskItem.querySelector('strong').textContent;
            // Cleans up the "New Task: " or "Task #1: " prefixes
            const cleanTitle = fullTitleText.replace(/^(New Task:|Task #\d+:)\s*/i, '');
            
            const metaText = taskItem.querySelector('.task-meta').textContent;
            // Split metaText ("Todo | Due: 2026-03-24") by the pipe character
            const metaParts = metaText.split('|');
            const statusValue = metaParts[0].trim();
            const datePart = metaParts[1] ? metaParts[1].replace('Due:', '').trim() : '';
            
            // Populate form inputs
            titleInput.value = cleanTitle;
            statusSelect.value = statusValue;
            // Populate date picker if a valid date string exists, otherwise clear it
            dueDateInput.value = (datePart && datePart !== 'No due date') ? datePart : '';

            // Switch button text to Update mode
            submitBtn.textContent = 'Update Task';
            
            // Focus on title input for better user experience
            titleInput.focus();
        }
    });

    // 3. Placeholder Interactions
    logoutBtn.addEventListener('click', () => {
        alert('Logout functionality is a placeholder for a future phase!');
    });

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault();
            alert('Routing to other tabs will be implemented in a future phase! For now, keep everything on this screen.');
        });
    });
});