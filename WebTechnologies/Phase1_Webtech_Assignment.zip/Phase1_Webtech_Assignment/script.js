document.addEventListener('DOMContentLoaded', () => {
    // Basic DOM Selection
    const taskForm = document.querySelector('.task-form');
    const tasksContainer = document.querySelector('.tasks-container');
    const titleInput = document.querySelector('#taskTitle');
    const statusSelect = document.querySelector('#taskStatus');
    const dueDateInput = document.querySelector('#taskDueDate');
    const validationMsg = document.querySelector('.validation-msg');
    
    // Select placeholder elements
    const logoutBtn = document.querySelector('.logout-btn');
    const navLinks = document.querySelectorAll('.nav-links a:not(.active)');

    // 1. Add Task Interaction
    taskForm.addEventListener('submit', function(event) {
        event.preventDefault(); // Prevent page refresh

        // Basic Validation
        const titleValue = titleInput.value.trim();
        if (titleValue === '') {
            // Show validation message if title is empty
            validationMsg.classList.remove('hidden');
            return;
        }
        
        // Hide validation message if input is valid
        validationMsg.classList.add('hidden');

        // Gather form values
        const statusValue = statusSelect.value;
        let dateValue = dueDateInput.value;
        if (!dateValue) {
            dateValue = 'No due date';
        }

        // Create new task element dynamically
        const newTask = document.createElement('div');
        newTask.classList.add('task-item');
        
        newTask.innerHTML = `
            <div class="task-info">
                <strong>New Task: ${titleValue}</strong>
                <span class="task-meta">${statusValue} | Due: ${dateValue}</span>
            </div>
            <button class="btn delete-btn">Delete</button>
        `;

        // Append to the list (Dynamic UI Update)
        tasksContainer.appendChild(newTask);

        // Reset the form after successful submission
        taskForm.reset();
    });

    // 2. Delete Task Interaction
    tasksContainer.addEventListener('click', function(event) {
        if (event.target.classList.contains('delete-btn')) {
            const taskItem = event.target.closest('.task-item');
            taskItem.remove(); // Removes the element dynamically
        }
    });

    // 3. Placeholder Interactions (For features coming in Phase 2!)
    logoutBtn.addEventListener('click', () => {
        alert('Logout functionality is a placeholder for a future phase!');
    });

    navLinks.forEach(link => {
        link.addEventListener('click', (e) => {
            e.preventDefault(); // Stop the link from trying to navigate
            alert('Routing to other tabs will be implemented in a future phase! For now, keep everything on this screen.');
        });
    });
});